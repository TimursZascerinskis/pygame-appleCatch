import pygame
import random

class Apple:
    def __init__(self):
        self.image = pygame.image.load("apple.png")
        self.image = pygame.transform.scale(self.image, (40, 40))
        self.x = random.randint(0, 600 - 40)
        self.y = -40
        self.speed = 5

    def update(self):
        self.y += self.speed
        if self.y > 800:
            self.reset()

    def reset(self):
        self.x = random.randint(0, 600 - 40)
        self.y = -40

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

    def get_rect(self):
        return pygame.Rect(self.x, self.y, 40, 40)

class Game:
    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode((600, 800))
        pygame.display.set_caption("Catch Apples")
        self.clock = pygame.time.Clock()
        self.run = True


        self.player_image = pygame.image.load("basket.png")
        self.player_image = pygame.transform.scale(self.player_image, (60, 60))
        self.player_x = 300
        self.player_y = 700
        self.player_speed = 7

        self.score = 0
        self.font = pygame.font.SysFont("Arial", 32)

        self.apple = Apple()

    def input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.run = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            self.run = False
        if keys[pygame.K_RIGHT]:
            self.player_x += self.player_speed
        if keys[pygame.K_LEFT]:
            self.player_x -= self.player_speed

    def update(self):
        self.player_x = max(0, min(self.player_x, 600 - 60))

        self.apple.update()

        if self.get_player_rect().colliderect(self.apple.get_rect()):
            self.score += 100
            print("Points:", self.score)
            self.apple.reset()

    def get_player_rect(self):
        return pygame.Rect(self.player_x, self.player_y, 60, 60)

    def draw(self):
        self.window.fill((50, 50, 50))

        self.window.blit(self.player_image, (self.player_x, self.player_y))

        self.apple.draw(self.window)

        score_text = self.font.render(f" {self.score}", True, (255, 255, 255))
        self.window.blit(score_text, (10, 10))

        pygame.display.update()

    def run_game(self):
        while self.run:
            self.input()
            self.update()
            self.draw()
            self.clock.tick(60)

        pygame.quit()

if __name__ == "__main__":
    game = Game()
    game.run_game()
